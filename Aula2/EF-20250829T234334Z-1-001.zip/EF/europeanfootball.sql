CREATE TABLE "clube" (
  "clb_sequencia" integer,
  "nome" varchar(200),
  "cmp_sequencia_domestica" char(5),
  "numero_jogadores" integer,
  "media_idade" decimal(18,8),
  "numero_estrangeiros" integer,
  "jogadores_selecao" integer,
  "nome_estadio" varchar(200),
  "assentos" integer,
  "ultima_temporada" integer
);

CREATE TABLE "jogador" (
  "jog_sequencia" integer,
  "primeiro_nome" varchar(200),
  "sobrenome" varchar(200),
  "nome" varchar(200),
  "ultima_temporada" integer,
  "clb_sequencia_atual" integer,
  "nacionalidade" varchar(200),
  "naturalidade" varchar(200),
  "cidadania" varchar(200),
  "nascimento" timestamp,
  "subposicao" varchar(200),
  "posicao" varchar(200),
  "dominante" varchar(200),
  "altura" decimal(18,8),
  "cmp_sequencia_atual" char(5),
  "equipe" varchar(200),
  "valor_mercado" decimal(18,8),
  "maior_valor_mercado" decimal(18,8)
);

CREATE TABLE "historico" (
  "gam_sequencia" integer,
  "mandante_clb_sequencia" integer,
  "mandante_gols" integer,
  "mandante_position" decimal(18,8),
  "mandante_tecnico" varchar(200),
  "visitante_clb_sequencia" integer,
  "visitante_gols" integer,
  "visitante_position" decimal(18,8),
  "visitante_tecnico" varchar(200),
  "tipo" varchar(200),
  "vitoria" integer
);

CREATE TABLE "competicao" (
  "cmp_sequencia" char(5),
  "nome" varchar(200),
  "subtipo" varchar(200),
  "tipo" varchar(200),
  "pais_sequencia" integer,
  "pais_nome" varchar(200),
  "cmp_sequencia_domestica" char(5),
  "competicao_principal" integer
);

CREATE TABLE "mercado" (
  "jog_sequencia" integer,
  "data" timestamp,
  "valor_mercado" integer,
  "clb_sequencia" integer,
  "cmp_sequencia" char(5)
);

CREATE TABLE "partida" (
  "gam_sequencia" integer,
  "cmp_sequencia" char(5),
  "temporada" integer,
  "rodada" varchar(200),
  "data" timestamp,
  "mandante_clb_sequencia" integer,
  "visitante_clb_sequencia" integer,
  "mandante_gols" integer,
  "visitante_gols" integer,
  "mandante_posicao" integer,
  "visitante_posicao" integer,
  "mandante_tecnico" varchar(200),
  "visitante_tecnico" varchar(200),
  "estadio" varchar(200),
  "publico" decimal(18,8),
  "arbitro" varchar(200),
  "mandante_formacao" varchar(200),
  "visitante_formacao" varchar(200),
  "agregado" varchar(200),
  "competicao_tipo" varchar(200)
);

CREATE TABLE "ocorrencia" (
  "data" timestamp,
  "gam_sequencia" integer,
  "minuto" integer,
  "tipo" varchar(200),
  "clb_sequencia" integer,
  "jog_sequencia" integer,
  "descricao" varchar(200),
  "jog_sequencia_entrada" integer,
  "jog_sequencia_assistencia" integer
);

CREATE TABLE "participacao" (
  "gam_sequencia" integer,
  "jog_sequencia" integer,
  "clb_sequencia" integer,
  "clb_sequencia_atual" integer,
  "date" timestamp,
  "cmp_sequencia" char(5),
  "cartao_amarelo" integer,
  "cartao_vermelho" integer,
  "gols" integer,
  "assistencia" integer,
  "minuto_em_campo" integer
);

CREATE TABLE "escalacao" (
  "data" timestamp,
  "gam_sequencia" integer,
  "jog_sequencia" integer,
  "clb_sequencia" integer,
  "tipo" varchar(200),
  "posicao" varchar(200),
  "numero" varchar(200),
  "capitao" integer
);
